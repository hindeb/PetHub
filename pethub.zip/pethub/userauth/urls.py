from django.urls import path
from .views import *

urlpatterns = [
    path('register/',UserRegisterationView.as_view(), name = "register"),
]
