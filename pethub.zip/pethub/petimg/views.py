from django.shortcuts import render
#from django.http import HttpResponse
from petimg.models import Pet

# Create your views here.
def pet_list(request):
    #return HttpResponse("Are we on the right track!!!")
    pet_objects = Pet.objects.all()
    return render(request,'pet/pet.html',{'pet_objects': pet_objects})