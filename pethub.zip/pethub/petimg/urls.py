from django.urls import path
from petimg import views

urlpatterns=[
    path('',views.pet_list)
]
