from django.urls import path
from . import views
from .views import *
# URLS for all pages and functions in PetHub
urlpatterns = [
    
    path('',views.home,name='home' ),
    path('pets/',views.pet_list),
    path('about/',views.about, name = 'about'),
    path('pets/',HomeView.as_view(), name = 'pets'),
    path('search/', search_pets, name='search_pets'),
    path('profile/<int:item_id>/', ProfileView.as_view(), name='profile'),
    path('addpet/',views.addpet, name = 'addpet'),
    path('contact/',views.contact, name = 'contact'),
]
