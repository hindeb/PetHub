from django.shortcuts import render, redirect
from . import views
from .models import Pet
from django.db.models import Q
from django.views.generic import ListView,DetailView
from django.core.mail import send_mail
from django.conf import settings
from .forms import PetForm
from django.http import HttpResponseRedirect


# Create your views here.
def home( request):
    return render(request, 'home.html',{})

def about( request):
    return render(request, 'about.html',{})

def pets( request):
    return render(request, 'pets.html',{})

def contact( request):
    return render(request, 'contact.html',{})


def pet_list(request):
    pet_objects = Pet.objects.all()
    return render(request, 'pets.html',{'pet_objects':pet_objects})

class HomeView(ListView):
    model = Pet
    template_name = 'pets.html'
    
class ProfileView(DetailView):
    def get(self, request, item_id):
        item = Pet.objects.get(id=item_id)
        context = {
            'item': item
        }
        return render(request, 'profile.html', context)

def addpet(request):
    if request.method == "POST":
        form = PetForm(request.POST)
        form.save()
        return redirect('pets')
    else:
        form = PetForm
    return render(request,'addpet.html', {'form': form})

def search_pets(request):
    search_term = request.GET.get('search_term')
    # Query across multiple fields using Q objects
    pets = Pet.objects.filter(
        Q(age__icontains=search_term) |
        Q(gender__icontains=search_term) |
        Q(type=search_term) |
        Q(status__icontains=search_term)
        # Add more fields as needed
    )
    
    context = {
        'pets': pets,
        'search_term': search_term,
    }
    return render(request, 'search.html', context)

#def apply(request, item_id):
    #if request.method == 'POST':
        # Process form submission and retrieve form data

        # Send email
        ##subject = 'Adoption Application'
        #message = 'This is my application for adopting the pet.'
        #from_email = settings.DEFAULT_FROM_EMAIL
        #recipient_list = ['recipient@example.com']  # Replace with the recipient email address
        #send_mail(subject, message, from_email, recipient_list)

        # Redirect or display a success message after sending the email

    # Render the template for GET requests
    #item = Item.objects.get(id=item_id)
    #context = {
    #    'item': item,
    #}
    #return render(request, 'apply.html', context)