from django import forms 
from django.forms import ModelForm
from .models import Pet

#Create a Pet Form
class PetForm(ModelForm):
    class Meta:
        model = Pet
        fields = ('name' , 'age', 'size', 'gender','type', 'size', 'personality_traits', 'status', 'short_description', 'image') 
        widgets = {
            'name': forms.TextInput(attrs={'class':'form-control'}) ,
            'age': forms.TextInput(attrs={'class':'form-control'}),
            'size': forms.TextInput(attrs={'class':'form-control'}),
            'gender': forms.TextInput(attrs={'class':'form-control'}),
            'type': forms.TextInput(attrs={'class':'form-control'}),
            'size': forms.TextInput(attrs={'class':'form-control'}),
            'personality_traits': forms.TextInput(attrs={'class':'form-control'}),
            'status': forms.TextInput(attrs={'class':'form-control'}),
            'short_description': forms.TextInput(attrs={'class':'form-control'}),
            'image': forms.TextInput(attrs={'class':'form-control'})
        }